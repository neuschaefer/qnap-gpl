/*
 * mac doesnt have a command line to read
 * prompt for one
 */

int parse_cmd_line(int max_argc,char **argv,int line_size,char *line);
