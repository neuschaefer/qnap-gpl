typedef struct saferplus_instance {
  byte l_key[33*16];
  word32 k_bytes;
} SPI;

